package sec03;

public class VarDemo {
//    var a = 1;

    public static void main(String[] args) {
        int var = 1;
        var x = 1;

//        var x = 1, y = 3, z = 4;

//        var str = null;

//        var oops;
//        oops = 1;
    }
	
//    void test(var x) {  }
}
